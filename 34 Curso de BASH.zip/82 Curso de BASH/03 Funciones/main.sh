#!/bin/bash

# Funciones

# Funcion para test de parametros
function testParametros
{
    # Despliega la suma
    echo "Parametro 1:" $1
    echo "Parametro 2:" $2
}

# -------------------------------------------------
# Función para obtener los archivos en un directorio
# --------------------------------------------------
function getArchivos
{
    # Comando de busqueda
    echo $1
    find -type f
    echo
}

# -------------------------------------------------
# Función para obtener los directorios en un directorio
# --------------------------------------------------
function getDirectorios 
{
    # Comando de busqueda
    echo $1
    find -type d
    echo 
}

# Utiliza las funciones
testParametros "Parametro 1"
testParametros x y

# Archivos
getArchivos 

# Directorios
getDirectorios 

