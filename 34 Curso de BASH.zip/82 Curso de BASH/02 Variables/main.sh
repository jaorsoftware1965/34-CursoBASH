#!/bin/bash

# Declarando 3 variables
greeting="Bienvenido"

# Tomando la información de variables de entorno
user=$(whoami)

# Tomando la fecha
day=$(date +%A)

# Desplegando la información
echo "$greeting de regreso $user! Hoy es $day, el cual es el mejor día de la semana!"
echo "La Versión del Bash shell es: $BASH_VERSION. Disfrútala!"