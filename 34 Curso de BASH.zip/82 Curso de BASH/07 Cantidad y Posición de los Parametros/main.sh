#!/bin/bash

# ---------------------------------------------------
# 07 Cantidad de parámetros y su posición
# ---------------------------------------------------

# Los parámetros cuando se envian todos generan consecutivamente
# variables de la forma:$1 $2 $3 ... $n

# Cualquiera de los parámetros puede ser omitido

# La variable $# nos indica el número de parámetros recibidos y
# en la variable $* se encuentran todos

# Función que despliega la cantidad de parametros, los parametros
# y realiza una suma
function fnSuma()
{
    echo "Número de parámetros recibidos:" $#    
    echo "Los parámetros son:" $*
    echo

    # Sumo los 2 valores ignorando el 2do
    suma=$(($1 + $3))

    # Lo retorno con echo
    echo "La suma es:" $suma
}


# Ejecuto y obtengo el resultado
fnSuma 4 cualquiercosa 5

