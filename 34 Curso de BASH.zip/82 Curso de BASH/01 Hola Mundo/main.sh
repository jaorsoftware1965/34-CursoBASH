#!/bin/bash

# ----------------------------------------------------------------------
# Curso de BASH Scripting
# Hola Mundo
# ----------------------------------------------------------------------

# para ver los atributos de un archivo
# ls -ls main.sh

# Cambiamos a que sea ejecutable
# chmod +x main.sh 

# La siguiente instrucción manda un mensaje a la pantall
echo "Hola Mundo"