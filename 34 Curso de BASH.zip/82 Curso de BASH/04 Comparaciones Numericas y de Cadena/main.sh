#!/bin/bash

# ---------------------------------------------------
# 04 Operadores de Comparación
# ---------------------------------------------------

# Description 	Numeric Comparison 	String Comparison
# less than 	        -lt 	            <
# greater than 	        -gt 	            >
# equal 	            -eq 	            =
# not equal 	        -ne 	            !=
# less or equal 	    -le 	            N/A
# greater or equal 	    -ge 	            N/A

# Ejemplos: 	
# [ 100 -eq 50 ]; echo $? 	
# [ “GNU” = “UNIX” ]; echo $?

# 0 = True
# 1 = False

# Declaramos 2 variables string
string_a="UNIX"
string_b="LINUX"

# Desplegamos un mensaje
echo "Son iguales $string_a y $string_b?"
[ $string_a = $string_b ]
echo $?

# Declaramos 2 numeros
num_a=100
num_b=100

# Comparamos
echo "Es $num_a igual a $num_b ?" 
[ $num_a -eq $num_b ]
echo $?
