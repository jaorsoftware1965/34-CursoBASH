#!/bin/bash

# ---------------------------------------------------
# 05 If then else
# ---------------------------------------------------

# Se declaran 2 variables numericas
num_a=40
num_b=200

# Se realiza una comparación con if
if [ $num_a -lt $num_b ]; then
    # Si es verdad la condición
    echo "$num_a es menor que $num_b!"
else
    # Si es falso la condición
    echo "$num_a es mayor que $num_b!"
fi
