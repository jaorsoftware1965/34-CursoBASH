#!/bin/bash

# ---------------------------------------------------
# 06 Funciones que retornan valores
# ---------------------------------------------------

# Función que retorna una suma
function fnSuma()
{
    # Sumo los 2 valores
    suma=$(($1 + $2))

    # Lo retorno con echo
    echo $suma
}

# Función que despliea un mensaje
function fnMensaje()
{
    # Creo el mensaje
    msg="Hola "$1

    # Lo retorno con echo
    echo $msg
}

# Ejecuto y obtengo el resultado
res=$(fnSuma 4 5)

# Despliego el resultado
echo "La suma es:" $res

# Ejecuto y obtengo el resultado
res=$(fnMensaje jaor)

# Despliego el resultado
echo "El Mensaje es:" $res

fnSuma 10 200

fnMensaje Ramirez
