#!/bin/bash

# ---------------------------------------------------
# 08 Ciclo For Loop
# ---------------------------------------------------

# Ciclo For
for i in 1 2 3; do
    echo $i
done
echo 

# Ciclo For
for i in `ls /home/linus1965`; do
    echo $i
done
